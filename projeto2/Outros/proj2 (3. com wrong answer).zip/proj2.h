/* Afonso da Conceição Ribeiro, 102763 */


#ifndef _PROJ_H_
#define _PROJ_H_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define MAX_AEROPORTOS 40			/* Número máximo de aeroportos */
#define MAX_VOOS 30000				/* Número máximo de voos */

#define MAX_CODIGO_AEROPORTO 4		/* Dimensão do código do aeroporto */
#define MAX_NOME_PAIS 31			/* Dimensão do nome do pais */
#define MAX_NOME_CIDADE 51			/* Dimensão do nome da cidade */
#define MAX_CODIGO_VOO 7			/* Dimensão do código do voo */
#define MAX_INSTRUCAO 65535			/* Dimensão de cada instrução */ /* ??? otimização para 65516 */

#define NAO_EXISTE -1				/* Código de erro */

#define ANO_INICIO 2022				/* Ano inicial do sistema */
#define DIAS_ANO 365				/* Número de dias num ano */
#define HORAS_DIA 24				/* Número de horas num dia */
#define MINUTOS_HORA 60				/* Número de minutos numa hora */
#define MINUTOS_DIA 1440			/* Número de minutos num dia */

#define ERRO_INVALID_AIRPORT_ID "invalid airport ID\n"
#define ERRO_TOO_MANY_AIRPORTS "too many airports\n"
#define ERRO_DUPLICATE_AIRPORT "duplicate airport\n"
#define ERRO_NO_SUCH_AIRPORT_ID ": no such airport ID\n"
#define ERRO_INVALID_FLIGHT_CODE "invalid flight code\n"
#define ERRO_FLIGHT_ALREADY_EXISTS "flight already exists\n"
#define ERRO_TOO_MANY_FLIGHTS "too many flights\n"
#define ERRO_INVALID_DATE "invalid date\n"
#define ERRO_INVALID_DURATION "invalid duration\n"
#define ERRO_INVALID_CAPACITY "invalid capacity\n"
#define ERRO_INVALID_RESERVATION_CODE "invalid reservation code\n"
#define ERRO_FLIGHT_CODE_DOES_NOT_EXIST ": flight does not exist\n"
#define ERRO_RESERVATION_ALREADY_USED ": flight reservation already used\n"
#define ERRO_TOO_MANY_RESERVATIONS "too many reservations\n"
#define ERRO_INVALID_PASSENGER_NUMBER "invalid passenger number\n"
#define ERRO_NOT_FOUND "not found\n"

#define ERRO_NO_MEMORY "No memory.\n"
#define EXIT_CODE_NO_MEMORY 1


typedef enum Bool {
	FALSE = 0,
	TRUE = 1
} Bool;


void* _malloc(int size);
void* _realloc(void* ptr, int size);
int leProximaPalavra(char str[]);
void lePalavraAteFimDeLinha(char str[]);
void leAteFimDeLinha();
void bubbleSort(int indexes[], int size, Bool (*cmpFunc) (int a, int b));
Bool eh_digito(char c);
Bool eh_maiuscula(char c);
void libertaMemoria();


#endif