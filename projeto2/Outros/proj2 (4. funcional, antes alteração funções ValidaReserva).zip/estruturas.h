/* Afonso da Conceição Ribeiro, 102763 */


#ifndef _ESTRUTURAS_
#define _ESTRUTURAS_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "proj2.h"
#include "data_hora.h"


typedef struct nodeReserva {
	struct nodeReserva *anterior;
	char *cod_v;
	Data *data;
    char *cod_r;
	int numPassageiros;
	struct nodeReserva *seguinte;
} *Reserva;

typedef struct Voo {
	char cod_v[MAX_CODIGO_VOO];
	char partida[MAX_CODIGO_AEROPORTO];
	char chegada[MAX_CODIGO_AEROPORTO];
	Data data;
	Hora hora;
	Hora duracao;
	int capacidade;
	int horaPartida;
	int horaChegada;
	Reserva primeira;
	int numPassageiros;
} Voo;

typedef struct Aeroporto {
	char id[MAX_CODIGO_AEROPORTO];
	char pais[MAX_NOME_PAIS];
	char cidade[MAX_NOME_CIDADE];
	int numVoos;
} Aeroporto;


extern int _numAeroportos;
extern Aeroporto _aeroportos[MAX_AEROPORTOS];
extern int _numVoos;
extern Voo _voos[MAX_VOOS];
extern Data _hoje;


void libertaVoo(int i_voo);
void eliminaVoos(char *cod_v);
void eliminaReserva(Reserva r, int *i);
void eliminaVoosReserva();
Bool cmpVoosPartida(int a, int b);
Bool cmpVoosChegada(int a, int b);
void listaVoosPartida();
void listaVoosChegada();
void alteraData();
void alocaAeroportosVoos();
Bool aeroportoInvalido(char id[]);
int encontraAeroporto(char id[]);
void adicionaAeroporto();
void mostraAeroporto(int index);
Bool cmpAeroportos(int a, int b);
void listaTodosAeroportos();
void listaAeroportos();
void mostraVoo(int index);
void mostraVooPartida(int index);
void mostraVooChegada(int index);
int encontraVoo(char cod_v[], Data d);
Bool validaCodigoVoo(char cod_v[]);
Bool validaVoo(Voo v);
void criaVoo(Voo v);
void adicionaListaVoos();
Bool validaCodigoReserva(char *cod_r, int len_cod_r);
Reserva encontraReserva(char *cod_r, int *p);
Bool validaReserva(Reserva r, int len_cod_r, int i_voo);
Bool validaVooReserva(char cod_v[], Data data, int i_voo);
void insereReservaOrdenada(Reserva nova_reserva, int i_voo);
void criaReserva(Reserva r, int i_voo);
void mostraReservas(int i_voo);
void adicionaListaReservas();


#endif