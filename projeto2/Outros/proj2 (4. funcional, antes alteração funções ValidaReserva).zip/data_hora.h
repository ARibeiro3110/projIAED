/* Afonso da Conceição Ribeiro, 102763 */


#ifndef _DATA_HORA_
#define _DATA_HORA_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "proj2.h"


typedef struct Data {
	int dia;
	int mes;
	int ano;
} Data;

typedef struct Hora {
	int hora;
	int minuto;
} Hora;


extern Data _hoje;
extern const int _diasMesAc[];


Hora leHora();
Data leData();
void mostraData(Data d);
void mostraHora(Hora h);
int converteDataNum(Data d);
int converteHoraNum(Hora h);
int converteDataHoraNum(Data d, Hora h);
Hora converteNumHora(int num);
Data converteNumData(int num);
Bool validaData(Data d);
Bool validaHora(Hora h);


#endif