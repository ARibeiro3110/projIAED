/* Afonso da Conceição Ribeiro, 102763 */


#include "estruturas.h"


/* DUVIDAS
    inicializacoes a NULL
    corrigir a funcao adicionaListaReservas
*/

/* Funções Aeroportos */

Bool aeroportoInvalido(char id[]) {
	int i;

	for (i = 0; id[i] != '\0'; i++)
		if (!(id[i] >= 'A' && id[i] <= 'Z'))
			return TRUE;

	return FALSE;
}

int encontraAeroporto(char id[]) {
	int i;

	for (i = 0; i < _numAeroportos; i++)
		if (!strcmp(id, _aeroportos[i].id))
			return i;
	
	return NAO_EXISTE;
}

void adicionaAeroporto() {
	Aeroporto a;

	leProximaPalavra(a.id);
	leProximaPalavra(a.pais);
	lePalavraAteFimDeLinha(a.cidade);

	if (aeroportoInvalido(a.id))
		printf(ERRO_INVALID_AIRPORT_ID);

	else if (_numAeroportos == MAX_AEROPORTOS)
		printf(ERRO_TOO_MANY_AIRPORTS);

	else if (encontraAeroporto(a.id) != NAO_EXISTE)
		printf(ERRO_DUPLICATE_AIRPORT);

	else {
		strcpy(_aeroportos[_numAeroportos].id, a.id);
		strcpy(_aeroportos[_numAeroportos].pais, a.pais);
		strcpy(_aeroportos[_numAeroportos].cidade, a.cidade);
		_aeroportos[_numAeroportos].numVoos = 0;
		_numAeroportos++;
		printf("airport %s\n", a.id);
	}
}

void mostraAeroporto(int index) {

	printf("%s %s %s %d\n", _aeroportos[index].id, _aeroportos[index].cidade,
							_aeroportos[index].pais,_aeroportos[index].numVoos);
}

Bool cmpAeroportos(int a, int b) {
	return (strcmp(_aeroportos[a].id, _aeroportos[b].id) > 0);
}

void listaTodosAeroportos() {
	int i;
	int indexAeroportos[MAX_AEROPORTOS];

	for (i = 0; i < _numAeroportos; i++)
		indexAeroportos[i] = i;

	bubbleSort(indexAeroportos, _numAeroportos, cmpAeroportos);

	for (i = 0; i < _numAeroportos; i++)
		mostraAeroporto(indexAeroportos[i]);
}

void listaAeroportos() {
	char id[MAX_CODIGO_AEROPORTO];
	int indexAeroporto, ultima = 0;

	ultima = leProximaPalavra(id);

	if (strlen(id) == 0)
		listaTodosAeroportos();

	else
		while (strlen(id) != 0) {
			indexAeroporto = encontraAeroporto(id);

			if (indexAeroporto == NAO_EXISTE)
				printf("%s" ERRO_NO_SUCH_AIRPORT_ID, id);
			else
				mostraAeroporto(indexAeroporto);
			
			if (!ultima)
				ultima = leProximaPalavra(id);
			else
				break;
		}
}


/* Funções Voos */

void mostraVoo(int index) {

	printf("%s %s %s ", _voos[index].cod_v, _voos[index].partida,
	    			    _voos[index].chegada);
	mostraData(_voos[index].data);
	printf(" ");
	mostraHora(_voos[index].hora);
	printf("\n");
}

void mostraVooPartida(int index) {

	printf("%s %s ", _voos[index].cod_v, _voos[index].chegada);
	mostraData(_voos[index].data);
	printf(" ");
	mostraHora(_voos[index].hora);
	printf("\n");
}

void mostraVooChegada(int index) {
	Hora h = converteNumHora(_voos[index].horaChegada);
	
	printf("%s %s ", _voos[index].cod_v, _voos[index].partida);
	mostraData(converteNumData(_voos[index].horaChegada));
	printf(" ");
	mostraHora(h);
	printf("\n");
}

int encontraVoo(char cod_v[], Data d) {
	int numData = converteDataNum(d);
	int i;

	for (i = 0; i < _numVoos; i++)
		if (!strcmp(cod_v, _voos[i].cod_v)
		    && numData == converteDataNum(_voos[i].data))
			return i;

	return NAO_EXISTE;
}

Bool validaCodigoVoo(char cod_v[]) {
	int i = 0, l = strlen(cod_v);

	if (l < 3)
		return FALSE;
	
	for (i = 0; i < 2; i++)
		if (!(cod_v[i] >= 'A' && cod_v[i] <= 'Z'))
			return FALSE;

	while (cod_v[i] != '\0') {
		if (!(cod_v[i] >= '0' && cod_v[i] <= '9'))
			return FALSE;
		i++;
	}
	
	return TRUE;
}

Bool validaVoo(Voo v) {

	if (validaCodigoVoo(v.cod_v) == FALSE)
		printf(ERRO_INVALID_FLIGHT_CODE);
	
	else if (encontraVoo(v.cod_v, v.data) != NAO_EXISTE)
		printf(ERRO_FLIGHT_ALREADY_EXISTS);
	
	else if (encontraAeroporto(v.partida) == NAO_EXISTE)
		printf("%s" ERRO_NO_SUCH_AIRPORT_ID, v.partida);
	
	else if (encontraAeroporto(v.chegada) == NAO_EXISTE)
		printf("%s" ERRO_NO_SUCH_AIRPORT_ID, v.chegada);
	
	else if (_numVoos == MAX_VOOS)
		printf(ERRO_TOO_MANY_FLIGHTS);
	
	else if (validaData(v.data) == FALSE)
		printf(ERRO_INVALID_DATE);
	
	else if (validaHora(v.duracao) == FALSE)
		printf(ERRO_INVALID_DURATION);
	
	else if (v.capacidade < 10)
		printf(ERRO_INVALID_CAPACITY);
	
	else
		return TRUE;
	
	return FALSE;
}

void criaVoo(Voo v) {

	strcpy(_voos[_numVoos].cod_v, v.cod_v);	
	strcpy(_voos[_numVoos].partida, v.partida);	
	strcpy(_voos[_numVoos].chegada, v.chegada);	
	_voos[_numVoos].data = v.data;	
	_voos[_numVoos].hora = v.hora;	
	_voos[_numVoos].duracao = v.duracao;	
	_voos[_numVoos].capacidade = v.capacidade;
	_voos[_numVoos].horaPartida = converteDataHoraNum(_voos[_numVoos].data,
													  _voos[_numVoos].hora);
	_voos[_numVoos].horaChegada = _voos[_numVoos].horaPartida +
							      converteHoraNum(_voos[_numVoos].duracao);
	_voos[_numVoos].primeira = NULL;
	_voos[_numVoos].numPassageiros = v.numPassageiros;
	
	_numVoos++;
}

void adicionaListaVoos() {
	Voo v;
	int i;

	if (leProximaPalavra(v.cod_v)) {
		for (i = 0; i < _numVoos; i++)
			mostraVoo(i);

		return;
	}
	
	else {
		leProximaPalavra(v.partida);
		leProximaPalavra(v.chegada);
		v.data = leData();
		v.hora = leHora();
		v.duracao = leHora();
		scanf("%d", &v.capacidade);
		v.numPassageiros = 0;
		leAteFimDeLinha();
	}

	if (validaVoo(v))
		criaVoo(v);
}


/* INÍCIO FUNÇÕES NOVAS */

Bool validaCodigoReserva(char *cod_r, int len_cod_r) {
	int i;

	if (len_cod_r < 10)
		return FALSE;
	
	for (i = 0; cod_r[i] != '\0'; i++)
		if (!eh_maiuscula(cod_r[i]) && !eh_digito(cod_r[i]))
			return FALSE;

	return TRUE;
}

Reserva encontraReserva(char *cod_r, int *p) {
	Reserva r;

	for(*p = 0; *p < _numVoos; (*p)++)
		for(r = _voos[*p].primeira; r != NULL; r = r->seguinte)
			if (!strcmp(r->cod_r, cod_r))
				return r;

	return NULL;
}

Bool validaReserva(Reserva r, int len_cod_r, int i_voo) {
	int i = 0, *p = &i;
	
	if (!validaCodigoReserva(r->cod_r, len_cod_r))
		printf(ERRO_INVALID_RESERVATION_CODE);
	else if (i_voo == NAO_EXISTE)
		printf("%s" ERRO_FLIGHT_CODE_DOES_NOT_EXIST, r->cod_v);
	else if (encontraReserva(r->cod_r, p) != NULL)
		printf("%s" ERRO_RESERVATION_ALREADY_USED, r->cod_r);
	else if (_voos[i_voo].numPassageiros + r->numPassageiros > _voos[i_voo].capacidade)
		printf(ERRO_TOO_MANY_RESERVATIONS);
	else if (!validaData(*(r->data)))
		printf(ERRO_INVALID_DATE);
	else if (r->numPassageiros <= 0)
		printf(ERRO_INVALID_PASSENGER_NUMBER);
	else
		return TRUE;
	return FALSE;

}

Bool validaVooReserva(char cod_v[], Data data, int i_voo) {

	if (i_voo == NAO_EXISTE)
		printf("%s" ERRO_FLIGHT_CODE_DOES_NOT_EXIST, cod_v);
	
    else if (!validaData(data))
		printf(ERRO_INVALID_DATE);
	
    else
		return TRUE;
	
    return FALSE;
}

void insereReservaOrdenada(Reserva nova_reserva, int i_voo) {
	Reserva aux;

	if (_voos[i_voo].primeira == NULL)
		_voos[i_voo].primeira = nova_reserva;

	else if (strcmp(nova_reserva->cod_r, _voos[i_voo].primeira->cod_r) < 0) {
		_voos[i_voo].primeira->anterior = nova_reserva;
		nova_reserva->seguinte = _voos[i_voo].primeira;
		_voos[i_voo].primeira = nova_reserva;
	}

	else {
		aux = _voos[i_voo].primeira;

		while (aux->seguinte != NULL && strcmp(aux->seguinte->cod_r, nova_reserva->cod_r) < 0)
			aux = aux->seguinte;
		
		nova_reserva->seguinte = aux->seguinte;

		if (aux->seguinte != NULL)
			nova_reserva->seguinte->anterior = nova_reserva;

		aux->seguinte = nova_reserva;
		nova_reserva->anterior = aux;
	}
}

void criaReserva(Reserva r, int i_voo) {
	r->anterior = NULL;
	r->seguinte = NULL;
	r->cod_v = _voos[i_voo].cod_v;

	insereReservaOrdenada(r, i_voo);

	_voos[i_voo].numPassageiros += r->numPassageiros;
}

void mostraReservas(int i_voo) {
	Reserva aux;

	for(aux = _voos[i_voo].primeira; aux != NULL; aux = aux->seguinte)
		printf("%s %d\n", aux->cod_r, aux->numPassageiros);
}

void adicionaListaReservas() {
	Reserva r = NULL;
	int c, len_cod_r = 0, i_voo;
	char *aux_cod_r, cod_v[MAX_CODIGO_VOO];
	Data data;

	r = (Reserva) _malloc(sizeof(struct nodeReserva));
	
	leProximaPalavra(cod_v);
	data = leData();

	i_voo = encontraVoo(cod_v, data);

	r->cod_v = cod_v;
	r->data = &(_voos[i_voo].data);


	if ((c = getchar()) != '\n') {
		aux_cod_r = (char *) _malloc(sizeof(char) * MAX_INSTRUCAO);
		scanf("%s %d", aux_cod_r, &(r->numPassageiros));

		len_cod_r = strlen(aux_cod_r);

		r->cod_r = (char *) _realloc(aux_cod_r, sizeof(char) * (len_cod_r + 1));

		if (validaReserva(r, len_cod_r, i_voo))
			criaReserva(r, i_voo);
		
		else {
			free(r->cod_r);
			free(r);
		}
	}
	else {
		if (validaVooReserva(cod_v, data, i_voo)) /* ??? alterar, fazer funcao diferente dependendo */
			mostraReservas(i_voo);
		free(r);
	}
}

/*****************************************************/

void libertaVoo(int i_voo) {
	Reserva aux;

	while (_voos[i_voo].primeira != NULL) {
		aux = _voos[i_voo].primeira;
		_voos[i_voo].primeira = _voos[i_voo].primeira->seguinte;
		free(aux->cod_r);
		free(aux);
	}
}

void eliminaVoos(char *cod_v) {
	int i, j;
    Bool found = FALSE;

	for (i = 0; i < _numVoos; i++)
		if(!strcmp(_voos[i].cod_v, cod_v)) {
			libertaVoo(i);

            _voos[i].capacidade = NAO_EXISTE;

			for (j = i; j < _numVoos - 1; j++) 
				_voos[j] = _voos[j + 1];

			found = TRUE;
			i--;
			_numVoos--;
		}
	
	if (!found)
		printf("not found\n");	
}

void eliminaReserva(Reserva r, int *i) { /* ??? copiar da net codigo para trabalhar em listas */

	if (r == NULL)
        printf(ERRO_NOT_FOUND);

    else {
        *i = encontraVoo(r->cod_v, *(r->data));
        _voos[*i].numPassageiros -= r->numPassageiros;

        /* If node to be deleted is head node */
        if (_voos[*i].primeira->cod_r == r->cod_r)
            _voos[*i].primeira = r->seguinte;

        /* Change next only if node to be deleted is NOT the last node */
        if (r->seguinte != NULL)
            r->seguinte->anterior = r->anterior;

        /* Change prev only if node to be deleted is NOT the first node */
        if (r->anterior != NULL)
            r->anterior->seguinte = r->seguinte;

        /* Finally, free the memory occupied by del*/
        free(r->cod_r);
        free(r);
    }
}

void eliminaVoosReserva() {
	char aux_codigo[MAX_INSTRUCAO];
	char *codigo;
	int len_codigo;
	int i = 0, *p = &i;

	scanf(" %s", aux_codigo);
	len_codigo = strlen(aux_codigo);

	codigo = (char *) _malloc(sizeof(char) * (len_codigo + 1));
	strcpy(codigo, aux_codigo);

	if (len_codigo < 10)
		eliminaVoos(codigo);
	else
		eliminaReserva(encontraReserva(codigo, p), p);
	
	free(codigo);
}

/* FIM FUNÇÕES NOVAS */


Bool cmpVoosPartida(int a, int b) {
	return (_voos[a].horaPartida > _voos[b].horaPartida);
}

Bool cmpVoosChegada(int a, int b) {
	return (_voos[a].horaChegada > _voos[b].horaChegada);
}

void listaVoosPartida() {
	int indexVoos[MAX_VOOS], i, n = 0;
	char partida[MAX_CODIGO_AEROPORTO];

	lePalavraAteFimDeLinha(partida);

	if (encontraAeroporto(partida) == NAO_EXISTE)
		printf("%s" ERRO_NO_SUCH_AIRPORT_ID, partida);

	for (i = 0; i < _numVoos; i++) {
		if (!strcmp(_voos[i].partida, partida))
			indexVoos[n++] = i;
	}

	bubbleSort(indexVoos, n, cmpVoosPartida);

	for (i = 0; i < n; i++)
		mostraVooPartida(indexVoos[i]);
}

void listaVoosChegada() {
	int indexVoos[MAX_VOOS], i, n = 0;
	char chegada[MAX_CODIGO_AEROPORTO];

	lePalavraAteFimDeLinha(chegada);

	if (encontraAeroporto(chegada) == NAO_EXISTE)
		printf("%s" ERRO_NO_SUCH_AIRPORT_ID, chegada);

	for (i = 0; i < _numVoos; i++) {
		if (!strcmp(_voos[i].chegada, chegada))
			indexVoos[n++] = i;
	}

	bubbleSort(indexVoos, n, cmpVoosChegada);

	for (i = 0; i < n; i++)
		mostraVooChegada(indexVoos[i]);
}

void alteraData() {
	Data d;

	d = leData();
	leAteFimDeLinha();
	if (!validaData(d))
		printf(ERRO_INVALID_DATE);
	else {
		_hoje = d;
		mostraData(_hoje);
		printf("\n");
	}
}
