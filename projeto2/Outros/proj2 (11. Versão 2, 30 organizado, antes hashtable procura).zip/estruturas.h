/* Afonso da Conceição Ribeiro, 102763 */


#ifndef _ESTRUTURAS_
#define _ESTRUTURAS_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "proj2.h"
#include "data_hora.h"
#include "aeroportos.h"
#include "voos.h"


#define ERRO_INVALID_RESERVATION_CODE "invalid reservation code\n"
#define ERRO_FLIGHT_CODE_DOES_NOT_EXIST ": flight does not exist\n"
#define ERRO_RESERVATION_ALREADY_USED ": flight reservation already used\n"
#define ERRO_TOO_MANY_RESERVATIONS "too many reservations\n"
#define ERRO_INVALID_PASSENGER_NUMBER "invalid passenger number\n"
#define ERRO_NOT_FOUND "not found\n"


struct nodeReserva {
	struct nodeReserva *anterior;
	Voo *voo;
    char *cod_r;
	int numPassageiros;
	struct nodeReserva *seguinte;
};


extern int _numAeroportos;
extern Aeroporto _aeroportos[MAX_AEROPORTOS];
extern int _numVoos;
extern Voo _voos[MAX_VOOS];
extern Data _hoje;


void libertaVoo(int i_voo);
void eliminaVoos(char *cod_v);
/*void eliminaReserva(Reserva r, int *i);*/
void eliminaVoosReserva();
Bool validaCodigoReserva(char *cod_r, int len_cod_r);
Reserva encontraReserva(char *cod_r, int *p);
Bool validaReserva(char cod_v[], Data d, char *cod_r, int numPassageiros, int len_cod_r, int i_voo);
Bool validaVooReserva(char cod_v[], Data data, int i_voo);
/*void insereReservaOrdenada(Reserva nova_reserva, Reserva head);*/
void criaReserva(Reserva r, int i_voo);
/*void mostraReservas(int i_voo);*/
void adicionaListaReservas();
void libertaMemoria();


#endif