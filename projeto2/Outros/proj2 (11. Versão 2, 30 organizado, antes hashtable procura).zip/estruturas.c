/* Afonso da Conceição Ribeiro, 102763 */


#include "estruturas.h"


/* DUVIDAS
    inicializacoes a NULL
    corrigir a funcao adicionaListaReservas
*/


/* INÍCIO FUNÇÕES NOVAS */

Bool validaCodigoReserva(char *cod_r, int len_cod_r) {
	int i, c;

	if (len_cod_r < 10)
		return FALSE;
	
	for (i = 0; (c = cod_r[i]) != '\0'; i++)
		if (!(eh_maiuscula(c) || eh_digito(c)))
			return FALSE;

	return TRUE;
}

Reserva encontraReserva(char *cod_r, int *p) {
	Reserva r;

	for(*p = 0; *p < _numVoos; (*p)++)
		for(r = _voos[*p].primeira; r != NULL; r = r->seguinte)
			if (!strcmp(r->cod_r, cod_r))
				return r;

	return NULL;
}

Bool validaReserva(char cod_v[], Data d, char *cod_r, int numPassageiros, int len_cod_r, int i_voo) {
	int i = 0, *p = &i;
	
	if (!validaCodigoReserva(cod_r, len_cod_r))
		printf(ERRO_INVALID_RESERVATION_CODE);
	
	else if (i_voo == NAO_EXISTE)
		printf("%s" ERRO_FLIGHT_CODE_DOES_NOT_EXIST, cod_v);
	
	else if (encontraReserva(cod_r, p) != NULL)
		printf("%s" ERRO_RESERVATION_ALREADY_USED, cod_r);
	
	else if (_voos[i_voo].capacidade < numPassageiros)
		printf(ERRO_TOO_MANY_RESERVATIONS);
	
	else if (!validaData(d))
		printf(ERRO_INVALID_DATE);
	
	else if (numPassageiros <= 0)
		printf(ERRO_INVALID_PASSENGER_NUMBER);
	
	else
		return TRUE;
	
	return FALSE;

}

Bool validaVooReserva(char cod_v[], Data data, int i_voo) {

	if (i_voo == NAO_EXISTE)
		printf("%s" ERRO_FLIGHT_CODE_DOES_NOT_EXIST, cod_v);
	
    else if (!validaData(data))
		printf(ERRO_INVALID_DATE);
	
    else
		return TRUE;
	
    return FALSE;
}

void insereReservaOrdenada(Reserva nova_reserva, int i_voo) {
	Reserva aux;

	/* Caso o Voo ainda não tenha reservas. */
	if (_voos[i_voo].primeira == NULL)
		_voos[i_voo].primeira = nova_reserva;

	/* Caso a nova reserva fique antes da atual primeira reserva do Voo, pela
	ordem lexicográfica dos códigos de reserva. */
	else if (strcmp(nova_reserva->cod_r, _voos[i_voo].primeira->cod_r) < 0) {
		_voos[i_voo].primeira->anterior = nova_reserva;
		nova_reserva->seguinte = _voos[i_voo].primeira;
		_voos[i_voo].primeira = nova_reserva;
	}

	else {
		aux = _voos[i_voo].primeira;

		while (aux->seguinte != NULL
			   && strcmp(aux->seguinte->cod_r, nova_reserva->cod_r) < 0)
			aux = aux->seguinte;
		
		nova_reserva->seguinte = aux->seguinte;

		/* Caso a nova reserva não fique em úlimo lugar. */
		if (aux->seguinte != NULL)
			nova_reserva->seguinte->anterior = nova_reserva;

		aux->seguinte = nova_reserva;
		nova_reserva->anterior = aux;
	}
}

Reserva novaReserva(int i_voo, char *cod_r, int numPassageiros) {
	Reserva r = (Reserva) _malloc(sizeof(struct nodeReserva));

	r->anterior = NULL;
	r->voo = &_voos[i_voo];
	r->cod_r = cod_r;
	r->numPassageiros = numPassageiros;
	r->seguinte = NULL;
	
	return r;
}

void mostraReserva(Reserva r) {
	printf("%s %d\n", r->cod_r, r->numPassageiros);
}

void mostraReservas(Reserva head) {
	Reserva aux;

	for(aux = head; aux != NULL; aux = aux->seguinte)
		mostraReserva(aux);
}

void adicionaListaReservas() {
	int c, len_cod_r = 0, i_voo, numPassageiros;
	char *cod_r, aux_cod_r[MAX_INSTRUCAO], cod_v[MAX_CODIGO_VOO];
	Data data;
	Reserva r;
	
	leProximaPalavra(cod_v);
	
	i_voo = encontraVoo(cod_v, data = leData());

	if ((c = getchar()) != '\n') {
		scanf("%s %d", aux_cod_r, &numPassageiros);
		len_cod_r = strlen(aux_cod_r);

		cod_r = (char *) _malloc(sizeof(char) * (len_cod_r + 1));
		strcpy(cod_r, aux_cod_r);

		if (validaReserva(cod_v, data, cod_r, numPassageiros, len_cod_r, i_voo)) {
			r = novaReserva(i_voo, cod_r, numPassageiros);
			insereReservaOrdenada(r, i_voo);
			_voos[i_voo].capacidade -= numPassageiros;
		}
		
		else 
			free(cod_r);
		
	}
	else {

		if (validaVooReserva(cod_v, data, i_voo)) /* ??? alterar, fazer funcao diferente dependendo */
			mostraReservas(_voos[i_voo].primeira);
	}
}

/*****************************************************/

void libertaVoo(int i_voo) {
	Reserva aux;
	/*char *cod_r;*/

	while (_voos[i_voo].primeira != NULL) {
		/*cod_r = _voos[i_voo].primeira->cod_r;*/
		/*STdelete*/
		aux = _voos[i_voo].primeira;
		_voos[i_voo].primeira = _voos[i_voo].primeira->seguinte;
		free(aux->cod_r);
		free(aux);
	}
}

void eliminaVoos(char *cod_v) {
	int i, j;
    Bool found = FALSE;

	for (i = 0; i < _numVoos; i++)
		if(!strcmp(_voos[i].cod_v, cod_v)) {
			libertaVoo(i);

			for (j = i; j < _numVoos - 1; j++) 
				_voos[j] = _voos[j + 1];

			found = TRUE;
			i--;
			_numVoos--;
		}
	
	if (!found)
		printf(ERRO_NOT_FOUND);
}

void eliminaReservaVoo(Reserva r) { /* ??? copiar da net codigo para trabalhar em listas */
	int i_voo;

	if (r == NULL)
        printf(ERRO_NOT_FOUND);

    else {
		i_voo = r->voo->i_voo;
        _voos[i_voo].capacidade += r->numPassageiros;

        /* Caso a reserva a eliminar seja a primeira. */
        if (_voos[i_voo].primeira->cod_r == r->cod_r)
            _voos[i_voo].primeira = r->seguinte;

        /* Caso a reserva a eliminar não seja a última. */
        if (r->seguinte != NULL)
            r->seguinte->anterior = r->anterior;

        /* Caso a reserva a eliminar não seja a primeira. */
        if (r->anterior != NULL)
            r->anterior->seguinte = r->seguinte;

        free(r->cod_r);
        free(r);
    }
}

void eliminaVoosReserva() {
	char *codigo, aux_codigo[MAX_INSTRUCAO];
	Reserva r;
	int len_codigo, i, *p = &i;

	scanf(" %s", aux_codigo);
	len_codigo = strlen(aux_codigo);

	codigo = (char *) _malloc(sizeof(char) * (len_codigo + 1));
	strcpy(codigo, aux_codigo);

	/* Caso o tamanho do código seja superior ao tamanho máximo de um código de
	voo, a função eliminaVoos() retorna o erro, ao comparar '\0' com outro caráter. */ /* ??? */
	if (len_codigo < 10)
		eliminaVoos(codigo);

	else {
		r = encontraReserva(codigo, p);
		/* if r != NULL stdelete */
		eliminaReservaVoo(r);
	}

	free(codigo);
}

void libertaMemoria() {
	int i;
	
	for(i = 0; i < _numVoos; i++)
		libertaVoo(i);
}