/* Afonso da Conceição Ribeiro, 102763 */


#ifndef _PROJ_H_ /* Funções gerais que podem ser úteis em qualquer parte. */
#define _PROJ_H_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define MAX_INSTRUCAO 65535			/* Dimensão de cada instrução */ /* ??? otimização para 65516 */
#define NAO_EXISTE -1				/* Código de erro */

#define ERRO_NO_MEMORY "No memory.\n"
#define EXIT_CODE_NO_MEMORY 0


typedef enum Bool {
	FALSE = 0,
	TRUE = 1
} Bool;


void* _malloc(int size);
void* _realloc(void* ptr, int size);
void _free(void* ptr);
int leProximaPalavra(char str[]);
void lePalavraAteFimDeLinha(char str[]);
void leAteFimDeLinha();
void bubbleSort(int indexes[], int size, Bool (*cmpFunc) (int a, int b));
Bool eh_digito(char c);
Bool eh_maiuscula(char c);


#endif