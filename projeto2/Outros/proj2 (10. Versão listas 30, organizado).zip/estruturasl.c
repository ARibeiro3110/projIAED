/* Afonso da Conceição Ribeiro, 102763 */


#include "estruturasl.h"


/* DUVIDAS
    inicializacoes a NULL
    corrigir a funcao adicionaListaReservas
*/


/* INÍCIO FUNÇÕES NOVAS */

Bool validaCodigoReserva(char *cod_r, int len_cod_r) {
	int i, c;

	if (len_cod_r < 10)
		return FALSE;
	
	for (i = 0; (c = cod_r[i]) != '\0'; i++)
		if (!(eh_maiuscula(c) || eh_digito(c)))
			return FALSE;

	return TRUE;
}

Reserva encontraReserva(char *cod_r, int *p) {
	Reserva r;

	for(*p = 0; *p < _numVoos; (*p)++)
		for(r = _voos[*p].primeira; r != NULL; r = r->seguinte)
			if (!strcmp(r->cod_r, cod_r))
				return r;

	return NULL;
}

Bool validaReserva(char cod_v[], Data d, Reserva r, int len_cod_r, int i_voo) {
	int i = 0, *p = &i;
	
	if (!validaCodigoReserva(r->cod_r, len_cod_r))
		printf(ERRO_INVALID_RESERVATION_CODE);
	
	else if (i_voo == NAO_EXISTE)
		printf("%s" ERRO_FLIGHT_CODE_DOES_NOT_EXIST, cod_v);
	
	else if (encontraReserva(r->cod_r, p) != NULL)
		printf("%s" ERRO_RESERVATION_ALREADY_USED, r->cod_r);
	
	else if (_voos[i_voo].capacidade < r->numPassageiros)
		printf(ERRO_TOO_MANY_RESERVATIONS);
	
	else if (!validaData(d))
		printf(ERRO_INVALID_DATE);
	
	else if (r->numPassageiros <= 0)
		printf(ERRO_INVALID_PASSENGER_NUMBER);
	
	else
		return TRUE;
	
	return FALSE;

}

Bool validaVooReserva(char cod_v[], Data data, int i_voo) {

	if (i_voo == NAO_EXISTE)
		printf("%s" ERRO_FLIGHT_CODE_DOES_NOT_EXIST, cod_v);
	
    else if (!validaData(data))
		printf(ERRO_INVALID_DATE);
	
    else
		return TRUE;
	
    return FALSE;
}

void insereReservaOrdenada(Reserva nova_reserva, int i_voo) {
	Reserva aux;

	/* Caso o Voo ainda não tenha reservas. */
	if (_voos[i_voo].primeira == NULL)
		_voos[i_voo].primeira = nova_reserva;

	/* Caso a nova reserva fique antes da atual primeira reserva do Voo, pela
	ordem lexicográfica dos códigos de reserva. */
	else if (strcmp(nova_reserva->cod_r, _voos[i_voo].primeira->cod_r) < 0) {
		_voos[i_voo].primeira->anterior = nova_reserva;
		nova_reserva->seguinte = _voos[i_voo].primeira;
		_voos[i_voo].primeira = nova_reserva;
	}

	else {
		aux = _voos[i_voo].primeira;

		while (aux->seguinte != NULL
			   && strcmp(aux->seguinte->cod_r, nova_reserva->cod_r) < 0)
			aux = aux->seguinte;
		
		nova_reserva->seguinte = aux->seguinte;

		/* Caso a nova reserva não fique em úlimo lugar. */
		if (aux->seguinte != NULL)
			nova_reserva->seguinte->anterior = nova_reserva;

		aux->seguinte = nova_reserva;
		nova_reserva->anterior = aux;
	}
}

void criaReserva(Reserva r, int i_voo) {
	r->anterior = NULL;
	r->seguinte = NULL;
	r->voo = &_voos[i_voo];

	insereReservaOrdenada(r, i_voo);

	_voos[i_voo].capacidade -= r->numPassageiros;
}

void mostraReserva(Reserva r) {
	printf("%s %d\n", r->cod_r, r->numPassageiros);
}

void mostraReservas(int i_voo) {
	Reserva aux;

	for(aux = _voos[i_voo].primeira; aux != NULL; aux = aux->seguinte)
		mostraReserva(aux);
}

void adicionaListaReservas() {
	int c, len_cod_r = 0, i_voo;
	char *aux_cod_r, cod_v[MAX_CODIGO_VOO];
	Data data;
	Reserva r = (Reserva) _malloc(sizeof(struct nodeReserva));
	
	leProximaPalavra(cod_v);
	
	i_voo = encontraVoo(cod_v, data = leData());

	if ((c = getchar()) != '\n') {
		aux_cod_r = (char *) _malloc(sizeof(char) * MAX_INSTRUCAO);
		scanf("%s %d", aux_cod_r, &(r->numPassageiros));

		len_cod_r = strlen(aux_cod_r);

		r->cod_r = (char *) _realloc(aux_cod_r, sizeof(char) * (len_cod_r + 1));

		if (validaReserva(cod_v, data, r, len_cod_r, i_voo))
			criaReserva(r, i_voo);
		
		else {
			free(r->cod_r);
			free(r);
		}
	}
	else {
		free(r);

		if (validaVooReserva(cod_v, data, i_voo)) /* ??? alterar, fazer funcao diferente dependendo */
			mostraReservas(i_voo);
	}
}

/*****************************************************/

void libertaVoo(int i_voo) {
	Reserva aux;

	while (_voos[i_voo].primeira != NULL) {
		aux = _voos[i_voo].primeira;
		_voos[i_voo].primeira = _voos[i_voo].primeira->seguinte;
		free(aux->cod_r);
		free(aux);
	}
}

void eliminaVoos(char *cod_v) {
	int i, j;
    Bool found = FALSE;

	for (i = 0; i < _numVoos; i++)
		if(!strcmp(_voos[i].cod_v, cod_v)) {
			libertaVoo(i);

            _voos[i].capacidade = NAO_EXISTE;

			for (j = i; j < _numVoos - 1; j++) 
				_voos[j] = _voos[j + 1];

			found = TRUE;
			i--;
			_numVoos--;
		}
	
	if (!found)
		printf(ERRO_NOT_FOUND);
}

void eliminaReserva(Reserva r, int *i) { /* ??? copiar da net codigo para trabalhar em listas */

	if (r == NULL)
        printf(ERRO_NOT_FOUND);

    else {
        _voos[*i].capacidade += r->numPassageiros;

        /* Caso a reserva a eliminar seja a primeira. */
        if (_voos[*i].primeira->cod_r == r->cod_r)
            _voos[*i].primeira = r->seguinte;

        /* Caso a reserva a eliminar não seja a última. */
        if (r->seguinte != NULL)
            r->seguinte->anterior = r->anterior;

        /* Caso a reserva a eliminar não seja a primeira. */
        if (r->anterior != NULL)
            r->anterior->seguinte = r->seguinte;

        free(r->cod_r);
        free(r);
    }
}

void eliminaVoosReserva() {
	char *aux_codigo, *codigo;
	int len_codigo, i, *p = &i;

	aux_codigo = (char *) _malloc(sizeof(char) * MAX_INSTRUCAO);

	scanf(" %s", aux_codigo);
	len_codigo = strlen(aux_codigo);

	codigo = (char *) _realloc(aux_codigo, sizeof(char) * (len_codigo + 1));

	/* Caso o tamanho do código seja superior ao tamanho máximo de um código de
	voo, a função eliminaVoos() retorna o erro, ao comparar '\0' com outro caráter. */ /* ??? */
	if (len_codigo < 10)
		eliminaVoos(codigo);

	else
		eliminaReserva(encontraReserva(codigo, p), p);
	
	free(codigo);
}

void libertaMemoria() {
	int i;
	
	for(i = 0; i < _numVoos; i++)
		libertaVoo(i);

}